import { Department } from '../types';

export const departments: Department[] = [
  {
    id: 'it',
    name: 'TI',
    icon: 'Laptop',
    description: 'Tecnologia da Informação'
  },
  {
    id: 'finance',
    name: 'Financeiro',
    icon: 'Banknote',
    description: 'Gestão Financeira'
  },
  {
    id: 'commercial',
    name: 'Comercial',
    icon: 'ShoppingCart',
    description: 'Vendas e Marketing'
  },
  {
    id: 'hr',
    name: 'RH',
    icon: 'Users',
    description: 'Recursos Humanos'
  },
  {
    id: 'supply',
    name: 'Supply',
    icon: 'Truck',
    description: 'Cadeia de Suprimentos'
  },
  {
    id: 'projects',
    name: 'Projetos',
    icon: 'Folder',
    description: 'Gestão de Projetos'
  }
];