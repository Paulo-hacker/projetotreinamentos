export interface Department {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface Training {
  id: string;
  title: string;
  description: string;
  department: string;
  duration: string;
  status: 'available' | 'in-progress' | 'completed';
}

export interface User {
  id: string;
  username: string;
  department: string;
}