import React from 'react';
import * as Icons from 'lucide-react';
import { Link } from 'react-router-dom';
import { Department } from '../types';

interface DepartmentCardProps {
  department: Department;
}

export function DepartmentCard({ department }: DepartmentCardProps) {
  // Dynamically get the icon component
  const IconComponent = Icons[department.icon as keyof typeof Icons];

  return (
    <Link
      to={`/training/${department.id}`}
      className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
    >
      <div className="flex items-center gap-4">
        <div className="p-3 bg-blue-100 rounded-lg">
          <IconComponent className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{department.name}</h3>
          <p className="text-sm text-gray-600">{department.description}</p>
        </div>
      </div>
    </Link>
  );
}