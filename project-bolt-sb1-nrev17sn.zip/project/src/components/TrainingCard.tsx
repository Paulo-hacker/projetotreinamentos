import React from 'react';
import { Clock, BookOpen } from 'lucide-react';
import { Training } from '../types';

interface TrainingCardProps {
  training: Training;
}

export function TrainingCard({ training }: TrainingCardProps) {
  const getStatusColor = (status: Training['status']) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-gray-900">{training.title}</h3>
        <span className={`px-2 py-1 rounded-full text-sm ${getStatusColor(training.status)}`}>
          {training.status === 'available' ? 'Disponível' : 
           training.status === 'in-progress' ? 'Em Andamento' : 'Concluído'}
        </span>
      </div>
      <p className="text-gray-600 mb-4">{training.description}</p>
      <div className="flex items-center gap-4 text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <Clock size={16} />
          <span>{training.duration}</span>
        </div>
        <button className="flex items-center gap-1 text-blue-600 hover:text-blue-700">
          <BookOpen size={16} />
          <span>Iniciar Treinamento</span>
        </button>
      </div>
    </div>
  );
}