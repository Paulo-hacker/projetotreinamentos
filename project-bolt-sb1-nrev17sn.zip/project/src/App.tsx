import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { PrivateRoute } from './components/PrivateRoute';
import { Sidebar } from './components/Sidebar';
import { Training } from './pages/Training';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { useAuth } from './context/AuthContext';

function AppContent() {
  const { user } = useAuth();

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    );
  }

  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 bg-gray-100 min-h-screen">
        <Routes>
          <Route path="/" element={
            <PrivateRoute>
              <div className="p-6">
                <h1 className="text-2xl font-bold">Bem-vindo à Intranet</h1>
              </div>
            </PrivateRoute>
          } />
          <Route path="/training" element={
            <PrivateRoute>
              <Training />
            </PrivateRoute>
          } />
          <Route path="/notifications" element={
            <PrivateRoute>
              <div className="p-6">
                <h1 className="text-2xl font-bold">Notificações</h1>
              </div>
            </PrivateRoute>
          } />
          <Route path="/settings" element={
            <PrivateRoute>
              <div className="p-6">
                <h1 className="text-2xl font-bold">Configurações</h1>
              </div>
            </PrivateRoute>
          } />
        </Routes>
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App;