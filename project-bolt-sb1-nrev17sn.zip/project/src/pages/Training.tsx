import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { departments } from '../data/departments';
import { DepartmentCard } from '../components/DepartmentCard';
import { TrainingCard } from '../components/TrainingCard';
import { AddTrainingModal } from '../components/AddTrainingModal';
import { useAuth } from '../context/AuthContext';
import { Training as TrainingType } from '../types';

// Example training data
const exampleTrainings: TrainingType[] = [
  {
    id: '1',
    title: 'Introdução ao React',
    description: 'Aprenda os fundamentos do React e como criar aplicações modernas',
    department: 'it',
    duration: '4 horas',
    status: 'available'
  },
  {
    id: '2',
    title: 'Gestão Financeira Básica',
    description: 'Conceitos fundamentais de gestão financeira e análise de dados',
    department: 'finance',
    duration: '6 horas',
    status: 'in-progress'
  },
  {
    id: '3',
    title: 'Técnicas de Vendas',
    description: 'Aprenda estratégias eficazes de vendas e negociação',
    department: 'commercial',
    duration: '3 horas',
    status: 'completed'
  }
];

export function Training() {
  const { user } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [trainings, setTrainings] = useState(exampleTrainings);
  
  const userDepartment = departments.find(dept => dept.id === user?.department);
  const departmentTrainings = trainings.filter(training => 
    training.department === user?.department || !user?.department
  );

  const handleAddTraining = (newTraining: Omit<TrainingType, 'id'>) => {
    const training: TrainingType = {
      ...newTraining,
      id: Date.now().toString()
    };
    setTrainings([...trainings, training]);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Treinamentos</h1>
          <p className="text-gray-600">
            {userDepartment 
              ? `Treinamentos disponíveis para ${userDepartment.name}`
              : 'Selecione um departamento para ver os treinamentos disponíveis'}
          </p>
        </div>
        {user && (
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <Plus size={20} />
            Adicionar Treinamento
          </button>
        )}
      </div>
      
      {!user?.department && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {departments.map((department) => (
            <DepartmentCard key={department.id} department={department} />
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departmentTrainings.map((training) => (
          <TrainingCard key={training.id} training={training} />
        ))}
      </div>

      <AddTrainingModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddTraining}
        departmentId={user?.department || ''}
      />
    </div>
  );
}